from django.shortcuts import render
from FinexApp.forms import LoginForm
from FinexApp.models import Login
# Create your views here.
def index(request):
    return render(request,"index.html")

def login(request):
    form=LoginForm()
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        if Login.objects.filter(username=username,password=password).exists():
            return index(request)
        else:
            return render(request,'login.html',{'form':form})
    return render(request,'login.html',{'form':form})
